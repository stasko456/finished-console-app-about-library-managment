﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_12
{
    public class Borrowing
    {
        private Reader reader;
        private Book book;
        private DateTime dateOfBorrowing;
        private DateTime dateOfReturn;

        public DateTime DateOfReturn
        {
            get { return this.dateOfReturn; }
            set { this.dateOfReturn = value; }
        }

        public DateTime DateOfBorrowing
        {
            get { return this.dateOfBorrowing; }
            set { this.dateOfBorrowing = value; }
        }

        public Book Book
        {
            get { return this.book; }
            set { this.book = value; }
        }

        public Reader Reader
        {
            get { return this.reader; }
            set { this.reader = value; }
        }

        public Borrowing(Book book, Reader reader, DateTime dateOfBorrowing, DateTime dateOfReturn)
        {
            this.DateOfBorrowing = dateOfBorrowing;
            this.DateOfReturn = dateOfReturn;
            this.Book = book;
            this.Reader = reader;
        }
    }
}
